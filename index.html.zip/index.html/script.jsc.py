document.getElementById('clickBtn').addEventListener('click', function() {
    document.getElementById('message').textContent = 'You clicked the button!';
});